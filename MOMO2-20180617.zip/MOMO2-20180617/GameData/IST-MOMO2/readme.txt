Title: MOMO2 Rocket MOD for Kerbal Space Program
License: LGPLv3
Contact: 88esplosione@gmail.com
How to Use: Watch the auxially png file.
Change log:
Version 0.1 (06/17/2018)
-Trademarks free version releace.
